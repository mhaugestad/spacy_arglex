# spacy_arglex
Project to detect arguments and opinions in corpus based on patterns described by Somasundaran et al. http://mpqa.cs.pitt.edu/lexicons/arg_lexicon/.

The module is built on top of spacy and tag sentences that expresses some argument with its corresponding label.


